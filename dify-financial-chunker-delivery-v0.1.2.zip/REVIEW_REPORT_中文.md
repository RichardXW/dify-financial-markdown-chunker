# 交付前审查报告

版本：`0.1.2`  
审查日期：`2026-09-10`

## 已完成验证

- Dify 官方 CLI `v0.6.6` 成功执行 `plugin package`。
- `manifest.yaml`、Provider YAML、Tool YAML 均可解析，文件引用完整。
- 输出字段与 Dify 官方 `multimodal_parent_child_structure.json` 的必需结构一致。
- Python 3.12 编译检查通过；Dify SDK 入口类可导入。
- `ruff 0.16.6` 静态检查通过，无未处理告警。
- 18 项自动化测试全部通过，包括混合 Markdown、长正文、嵌套列表、长表格、代码围栏、财务数字格式、精度、Parent 去重及模拟 Dify API 重试。
- 确定性压力测试通过：200 份混合文档，1,119 个 Parent、12,209 个 Child，无异常，耗时约 0.3 秒（本机结果，仅作稳定性冒烟测试）。
- 脱敏样例本地评测通过：Recall@1/3/5/10、MRR、Numeric Hit@K、Trigger Numeric Hit@K、Unit Hit@K 均为 1.0。该结果只证明样例链路，不代表真实语料效果。
- 三个 PowerShell 脚本均通过语法解析；评测器的 Dify API 路径已使用 mock 响应验证，不会在测试中访问真实服务。
- `pip check` 通过；运行依赖固定为已验证的 `dify_plugin==0.5.1`。
- 密钥特征扫描未发现私钥、云访问密钥、OpenAI Key、Dify Dataset Key 或硬编码 Bearer Token。
- `.difypkg` 内容已审计，不含 `.venv`、缓存、测试、样例、评测脚本或开发依赖。

## 已修正的关键问题

- 避免 `2460` 被错误判定为命中 `12460`。
- 本地检索按 Child 建索引、按 Parent 返回并去重，更接近 Dify 父子检索。
- 支持粗体、行内代码、脚注、会计括号负数、币种代码和常用中英文金融单位。
- 多行表名/币种/单位/口径/来源可继承到表格 Child。
- 长嵌套列表每个分片重复路径，长代码块每个分片保持完整围栏。
- Dify API 评测增加可重试错误、超时、企业 CA 及新旧权重格式支持。

## 必须在公司内网完成的验证

外部环境无法代替验证公司的 Dify 版本、Plugin Daemon 依赖镜像、Embedding、Reranker、企业证书、权限策略和真实 OCR 质量。正式上线前请按 `source/DEPLOYMENT_CHECKLIST_中文.md` 在隔离测试环境完成真实安装、索引和检索验收。复杂合并表头或跨页续表必须先由上游解析器恢复结构。

官方结构参考：

- https://docs.dify.ai/en/develop-plugin/dev-guides-and-walkthroughs/develop-multimodal-data-processing-tool
- https://docs.dify.ai/en/develop-plugin/features-and-specs/plugin-types/plugin-info-by-manifest
