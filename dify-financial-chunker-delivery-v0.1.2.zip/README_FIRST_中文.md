# 先看这里

这是一套可离线带入内网的 Dify 金融混合 Markdown 分块器交付物。

1. 先阅读 `QUICKSTART_中文.md` 和 `DEPLOYMENT_CHECKLIST_中文.md`。
2. 在测试环境通过“插件 → 通过本地文件”安装交付根目录中的 `dify-financial-chunker.difypkg`。
3. 用 `examples/` 完成离线评测，再换成经批准的内网数据。
4. 真实数据不要发出内网；默认报告不含问题、答案和召回原文。
5. 可用 `scripts/verify_difypkg.ps1` 检查插件包结构和 SHA-256。

运行本地冒烟测试：

```powershell
cd source
python -m unittest discover -s tests -v
.\scripts\run_local_evaluation.ps1
```

交付根目录的 `SHA256SUMS.txt` 记录了可安装插件包的校验值。真实 Dify 的模型、索引、Reranker 和内部证书配置无法在外部机器代替验证，因此正式上线前必须在公司的隔离测试环境完成一次真实安装和检索验收。
