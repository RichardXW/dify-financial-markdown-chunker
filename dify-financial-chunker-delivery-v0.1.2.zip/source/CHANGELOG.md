# Changelog

## 0.1.2 — 2026-09-10

- Added exact numeric-token evaluation to prevent substring false positives such as `2460` matching `12460`.
- Made local evaluation index Child text while returning and deduplicating Parent evidence.
- Added Trigger Numeric Hit@K, Dify API retries, corporate CA support, and mock API tests.
- Added support for Markdown-formatted values, footnotes, ISO currency codes, common financial units, and precise large integers.
- Preserved multiple table context lines and repeated paths/fences when long list or code blocks are split.
- Added Windows and Unix evaluation wrappers, a case JSON Schema, and an internal deployment checklist.

## 0.1.1 — 2026-09-09

- Added mixed Markdown parsing for headings, narrative text, nested lists, tables, and code fences.
- Added table Parent chunks, per-row comparison Children, and per-cell numeric fact Children.
- Added local and Dify Recall@K evaluation scripts and privacy-safe reports.
