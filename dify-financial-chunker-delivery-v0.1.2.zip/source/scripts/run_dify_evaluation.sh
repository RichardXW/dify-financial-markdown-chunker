#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 4 ]; then
  echo "Usage: $0 BASE_URL DATASET_ID CASES_JSON OUTPUT_JSON [extra evaluator options]" >&2
  exit 64
fi
: "${DIFY_DATASET_API_KEY:?Set DIFY_DATASET_API_KEY before running this script}"

base_url="$1"
dataset_id="$2"
cases_path="$3"
output_path="$4"
shift 4

script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
python_command="${PYTHON_COMMAND:-python3}"

"$python_command" "$script_dir/evaluate_retrieval.py" \
  --mode dify \
  --base-url "$base_url" \
  --dataset-id "$dataset_id" \
  --cases "$cases_path" \
  --output "$output_path" \
  --search-method hybrid_search \
  -k 1 -k 3 -k 5 -k 10 \
  "$@"
