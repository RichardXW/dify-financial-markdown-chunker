param(
    [string]$DocumentsDir = (Join-Path $PSScriptRoot '..\examples\eval-docs'),
    [string]$Cases = (Join-Path $PSScriptRoot '..\examples\evaluation_cases.json'),
    [string]$Output = (Join-Path $PSScriptRoot '..\examples\evaluation_report.json'),
    [int]$ParentChunkSize = 1800,
    [int]$ChildChunkSize = 450,
    [string]$Entity = '',
    [string]$Currency = '',
    [string]$Unit = '',
    [string]$PythonCommand = 'python'
)

$ErrorActionPreference = 'Stop'
$evaluator = Join-Path $PSScriptRoot 'evaluate_retrieval.py'

$arguments = @(
    $evaluator,
    '--mode', 'local',
    '--documents-dir', $DocumentsDir,
    '--cases', $Cases,
    '--output', $Output,
    '--parent-chunk-size', $ParentChunkSize,
    '--child-chunk-size', $ChildChunkSize,
    '--entity', $Entity,
    '--currency', $Currency,
    '--unit', $Unit,
    '-k', '1', '-k', '3', '-k', '5', '-k', '10'
)

& $PythonCommand @arguments
exit $LASTEXITCODE
