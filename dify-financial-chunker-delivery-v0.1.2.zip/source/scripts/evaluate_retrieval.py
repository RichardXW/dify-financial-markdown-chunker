#!/usr/bin/env python3
"""Offline-safe Recall@K and numeric-hit evaluation for the Dify chunker.

Local mode evaluates the generated child chunks with a deterministic BM25-style
retriever. Dify mode evaluates an indexed Dify Knowledge Base through its
`POST /v1/datasets/{dataset_id}/retrieve` API.

The default report contains aggregate metrics and case IDs only. Retrieved text,
queries, and expected answers are never written unless --include-debug-content
is explicitly supplied.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import ssl
import sys
import time
import urllib.error
import urllib.request
from collections import Counter
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from tools.financial_chunker_core import build_parent_child_chunks

DEFAULT_KS = (1, 3, 5, 10)
NUMBER_TOKEN = re.compile(
    r"(?<![\w.])(?P<open>\()?(?:(?:USD|HKD|CNY|RMB|EUR|GBP|JPY|US\$|HK\$)\s*)?"
    r"(?:[$¥￥£€]\s*)?(?P<number>[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)"
    r"\s*(?P<percent>%|％)?\s*(?:(?:USD|HKD|CNY|RMB|EUR|GBP|JPY)\s*)?"
    r"(?:(?:千|万|百万|千万|亿|十亿)?(?:人民币|美元|港元|欧元|英镑|日元|元)|"
    r"(?:人民币|美元|港元|欧元|英镑|日元)(?:千|万|百万|千万|亿|十亿)|"
    r"千|万|百万|千万|亿|十亿|个百分点|基点|倍|"
    r"thousand|million|billion|mn|bn|bps|k)?(?P<close>\))?(?![\w.])",
    re.IGNORECASE,
)
ASCII_TOKEN = re.compile(r"[A-Za-z]+(?:[-_][A-Za-z0-9]+)*|\d+(?:\.\d+)?%?")
CHINESE_RUN = re.compile(r"[\u3400-\u9fff]+")


@dataclass
class RetrievedChunk:
    content: str
    document_name: str = ""
    score: float = 0.0
    retrieval_content: str = ""
    evidence_id: str = ""


def parse_weights(value: str) -> float | dict[str, Any]:
    """Accept legacy numeric weights or the newer Dify weight JSON object."""
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as error:
        raise argparse.ArgumentTypeError(
            "weights must be a number or a JSON object"
        ) from error
    if isinstance(parsed, bool) or not isinstance(parsed, (int, float, dict)):
        raise argparse.ArgumentTypeError("weights must be a number or a JSON object")
    return float(parsed) if isinstance(parsed, (int, float)) else parsed


def normalize_number(value: str) -> str:
    match = NUMBER_TOKEN.fullmatch(value.strip())
    if not match:
        return value.strip().lower()
    negative = bool(match.group("open") and match.group("close"))
    number_text = match.group("number").replace(",", "")
    try:
        number = Decimal(number_text)
    except InvalidOperation:
        return value.strip().lower()
    if negative:
        number = -abs(number)
    normalized = format(number, "f")
    if "." in normalized:
        normalized = normalized.rstrip("0").rstrip(".")
    return f"{normalized}%" if match.group("percent") else normalized


def normalize_for_match(text: str) -> str:
    text = text.lower().replace("％", "%")
    return NUMBER_TOKEN.sub(lambda match: normalize_number(match.group(0)), text)


def numeric_tokens(text: str) -> set[str]:
    return {normalize_number(match.group(0)) for match in NUMBER_TOKEN.finditer(text)}


def tokenize(text: str) -> list[str]:
    normalized = normalize_for_match(text)
    tokens = [token.lower() for token in ASCII_TOKEN.findall(normalized)]
    for run in CHINESE_RUN.findall(normalized):
        tokens.extend(
            run if len(run) == 1 else [run[i : i + 2] for i in range(len(run) - 1)]
        )
    return tokens


class BM25Retriever:
    def __init__(self, chunks: list[RetrievedChunk], k1: float = 1.5, b: float = 0.75):
        self.chunks = chunks
        self.k1 = k1
        self.b = b
        self.term_counts = [
            Counter(tokenize(chunk.retrieval_content or chunk.content))
            for chunk in chunks
        ]
        self.lengths = [sum(counts.values()) for counts in self.term_counts]
        self.avg_length = sum(self.lengths) / max(len(self.lengths), 1)
        self.document_frequency: Counter[str] = Counter()
        for counts in self.term_counts:
            self.document_frequency.update(counts.keys())

    def search(self, query: str, top_k: int) -> list[RetrievedChunk]:
        query_terms = Counter(tokenize(query))
        total = len(self.chunks)
        scored: list[RetrievedChunk] = []
        normalized_query = normalize_for_match(query)
        for index, counts in enumerate(self.term_counts):
            score = 0.0
            length = self.lengths[index]
            for term, query_frequency in query_terms.items():
                frequency = counts.get(term, 0)
                if not frequency:
                    continue
                df = self.document_frequency[term]
                idf = math.log(1 + (total - df + 0.5) / (df + 0.5))
                denominator = frequency + self.k1 * (
                    1 - self.b + self.b * length / max(self.avg_length, 1)
                )
                score += idf * frequency * (self.k1 + 1) / denominator * query_frequency
            source = self.chunks[index]
            retrieval_content = source.retrieval_content or source.content
            normalized_content = normalize_for_match(retrieval_content)
            if normalized_query and normalized_query in normalized_content:
                score += 5.0
            if score > 0:
                scored.append(
                    RetrievedChunk(
                        content=source.content,
                        document_name=source.document_name,
                        score=score,
                        retrieval_content=retrieval_content,
                        evidence_id=source.evidence_id,
                    )
                )
        scored.sort(key=lambda item: item.score, reverse=True)
        # Dify parent-child retrieval returns a parent once even if several children hit.
        deduplicated: list[RetrievedChunk] = []
        seen: set[str] = set()
        for item in scored:
            key = item.evidence_id or f"content:{item.content}"
            if key in seen:
                continue
            seen.add(key)
            deduplicated.append(item)
            if len(deduplicated) >= top_k:
                break
        return deduplicated


def load_cases(path: Path) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    cases = payload.get("cases") if isinstance(payload, dict) else payload
    if not isinstance(cases, list) or not cases:
        raise ValueError("cases JSON must contain a non-empty 'cases' array")
    required = {"id", "query"}
    seen: set[str] = set()
    for case in cases:
        if not isinstance(case, dict) or not required.issubset(case):
            raise ValueError("every case must be an object containing id and query")
        case_id = str(case["id"]).strip()
        if not case_id or not str(case["query"]).strip():
            raise ValueError("every case must have a non-empty id and query")
        if case_id in seen:
            raise ValueError(f"duplicate case id: {case_id}")
        if not any(
            case.get(field) for field in ("must_contain", "any_of", "expected_document")
        ):
            raise ValueError(
                f"case {case_id} needs must_contain, any_of, or expected_document"
            )
        for field in ("must_contain", "any_of"):
            if field in case and not isinstance(case[field], list):
                raise ValueError(f"case {case_id} field {field} must be an array")
            if field in case and any(
                not isinstance(item, str) or not item.strip() for item in case[field]
            ):
                raise ValueError(
                    f"case {case_id} field {field} must contain non-empty strings"
                )
        if "expected_document" in case and not isinstance(
            case["expected_document"], str
        ):
            raise ValueError(f"case {case_id} field expected_document must be a string")
        case["id"] = case_id
        seen.add(case_id)
    return cases


def load_local_chunks(
    documents_dir: Path, args: argparse.Namespace
) -> list[RetrievedChunk]:
    chunks: list[RetrievedChunk] = []
    paths = sorted(documents_dir.rglob("*.md"))
    if not paths:
        raise ValueError(f"no .md files found under {documents_dir}")
    for path in paths:
        result = build_parent_child_chunks(
            path.read_text(encoding="utf-8"),
            document_name=path.name,
            entity=args.entity,
            currency=args.currency,
            unit=args.unit,
            parent_chunk_size=args.parent_chunk_size,
            child_chunk_size=args.child_chunk_size,
        )
        for parent_index, parent in enumerate(result["parent_child_chunks"]):
            parent_content = str(parent["parent_content"])
            for child in parent["child_contents"]:
                chunks.append(
                    RetrievedChunk(
                        content=parent_content,
                        document_name=path.name,
                        retrieval_content=str(child),
                        evidence_id=f"{path.resolve()}:{parent_index}",
                    )
                )
    return chunks


def dify_search(
    case: dict[str, Any], args: argparse.Namespace, top_k: int
) -> list[RetrievedChunk]:
    api_key = os.environ.get(args.api_key_env, "")
    if not api_key:
        raise ValueError(f"environment variable {args.api_key_env} is empty")
    base_url = args.base_url.rstrip("/")
    if not base_url.endswith("/v1"):
        base_url += "/v1"
    url = f"{base_url}/datasets/{args.dataset_id}/retrieve"
    retrieval_model: dict[str, Any] = {
        "search_method": args.search_method,
        "reranking_enable": args.reranking_enable,
        "top_k": top_k,
        "score_threshold_enabled": False,
    }
    if args.search_method == "hybrid_search" and args.weights is not None:
        retrieval_model["weights"] = args.weights
    if args.reranking_enable:
        retrieval_model["reranking_mode"] = args.reranking_mode
        if args.reranking_provider and args.reranking_model:
            retrieval_model["reranking_model"] = {
                "reranking_provider_name": args.reranking_provider,
                "reranking_model_name": args.reranking_model,
            }
    payload = json.dumps(
        {"query": str(case["query"]), "retrieval_model": retrieval_model},
        ensure_ascii=False,
    ).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=payload,
        method="POST",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
    )
    context = ssl.create_default_context(
        cafile=str(args.ca_bundle) if args.ca_bundle else None
    )
    data: dict[str, Any] | None = None
    for attempt in range(args.retries + 1):
        try:
            with urllib.request.urlopen(
                request, timeout=args.timeout, context=context
            ) as response:
                data = json.loads(response.read().decode("utf-8"))
            break
        except urllib.error.HTTPError as error:
            if error.code not in {429, 500, 502, 503, 504} or attempt >= args.retries:
                raise
        except urllib.error.URLError:
            if attempt >= args.retries:
                raise
        time.sleep(min(2**attempt, 8))
    if data is None:
        raise RuntimeError("Dify returned no response")
    if not isinstance(data, dict):
        raise TypeError("Dify response must be a JSON object")
    records = data.get("records", [])
    if not isinstance(records, list):
        raise TypeError("Dify response field 'records' must be an array")
    output: list[RetrievedChunk] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        segment = record.get("segment") or {}
        if not isinstance(segment, dict):
            segment = {}
        document = segment.get("document") or {}
        if not isinstance(document, dict):
            document = {}
        content = str(segment.get("content") or record.get("content") or "")
        child_chunks = segment.get("child_chunks") or record.get("child_chunks") or []
        child_texts = [
            str(child.get("content") or "")
            for child in child_chunks
            if isinstance(child, dict)
        ]
        output.append(
            RetrievedChunk(
                content=content,
                document_name=str(
                    document.get("name") or segment.get("document_name") or ""
                ),
                score=float(record.get("score") or 0.0),
                retrieval_content="\n".join(child_texts) or content,
                evidence_id=str(segment.get("id") or record.get("id") or ""),
            )
        )
    return output


def contains_term(content: str, term: str) -> bool:
    expected_numbers = numeric_tokens(term)
    residue = NUMBER_TOKEN.sub("", term)
    if expected_numbers and not re.search(r"[A-Za-z\u3400-\u9fff]", residue):
        return expected_numbers.issubset(numeric_tokens(content))
    return normalize_for_match(term) in normalize_for_match(content)


def contains_expected(chunk: RetrievedChunk, case: dict[str, Any]) -> bool:
    content = normalize_for_match(chunk.content)
    document_name = chunk.document_name.lower()
    expected_document = str(case.get("expected_document") or "").lower()
    if expected_document and expected_document not in document_name:
        return False
    for term in case.get("must_contain", []):
        if not contains_term(content, str(term)):
            return False
    any_of = case.get("any_of", [])
    if any_of and not any(contains_term(content, str(term)) for term in any_of):
        return False
    return bool(case.get("must_contain") or any_of or expected_document)


def contains_value(chunk: RetrievedChunk, expected_value: Any) -> bool:
    if expected_value is None or str(expected_value).strip() == "":
        return False
    expected_tokens = numeric_tokens(str(expected_value))
    return bool(
        expected_tokens and expected_tokens.issubset(numeric_tokens(chunk.content))
    )


def contains_unit(chunk: RetrievedChunk, expected_unit: Any) -> bool:
    if expected_unit is None or str(expected_unit).strip() == "":
        return False
    return str(expected_unit).lower() in chunk.content.lower()


def safe_error(error: Exception) -> str:
    if isinstance(error, urllib.error.HTTPError):
        return f"HTTP {error.code}"
    if isinstance(error, urllib.error.URLError):
        return f"network error: {error.reason}"
    return f"{type(error).__name__}: {error}"


def evaluate(args: argparse.Namespace) -> dict[str, Any]:
    cases = load_cases(args.cases)
    ks = tuple(sorted(set(args.k)))
    max_k = max(ks)
    local_retriever: BM25Retriever | None = None
    chunk_count: int | None = None
    if args.mode == "local":
        chunks = load_local_chunks(args.documents_dir, args)
        chunk_count = len(chunks)
        local_retriever = BM25Retriever(chunks)

    recall_hits = {k: 0 for k in ks}
    numeric_hits = {k: 0 for k in ks}
    trigger_numeric_hits = {k: 0 for k in ks}
    unit_hits = {k: 0 for k in ks}
    numeric_cases = 0
    unit_cases = 0
    reciprocal_rank_sum = 0.0
    case_reports: list[dict[str, Any]] = []
    started = time.time()

    for case in cases:
        case_report: dict[str, Any] = {"id": str(case["id"])}
        try:
            if local_retriever is not None:
                retrieved = local_retriever.search(str(case["query"]), max_k)
            else:
                retrieved = dify_search(case, args, max_k)
            relevance = [contains_expected(chunk, case) for chunk in retrieved]
            rank = next((i + 1 for i, matched in enumerate(relevance) if matched), None)
            case_report["relevant_rank"] = rank
            case_report["retrieved_count"] = len(retrieved)
            if rank:
                reciprocal_rank_sum += 1.0 / rank
            for k in ks:
                if any(relevance[:k]):
                    recall_hits[k] += 1

            expected_value = case.get("expected_value")
            if expected_value is not None:
                numeric_cases += 1
                numeric_flags = [
                    relevance[i] and contains_value(chunk, expected_value)
                    for i, chunk in enumerate(retrieved)
                ]
                trigger_numeric_flags = [
                    relevance[i]
                    and bool(
                        numeric_tokens(str(expected_value)).intersection(
                            numeric_tokens(chunk.retrieval_content or chunk.content)
                        )
                    )
                    for i, chunk in enumerate(retrieved)
                ]
                for k in ks:
                    if any(numeric_flags[:k]):
                        numeric_hits[k] += 1
                    if any(trigger_numeric_flags[:k]):
                        trigger_numeric_hits[k] += 1
                case_report["numeric_hit_at_max_k"] = any(numeric_flags)
                case_report["trigger_numeric_hit_at_max_k"] = any(trigger_numeric_flags)

            expected_unit = case.get("expected_unit")
            if expected_unit is not None:
                unit_cases += 1
                unit_flags = [
                    relevance[i] and contains_unit(chunk, expected_unit)
                    for i, chunk in enumerate(retrieved)
                ]
                for k in ks:
                    if any(unit_flags[:k]):
                        unit_hits[k] += 1
                case_report["unit_hit_at_max_k"] = any(unit_flags)

            if args.include_debug_content:
                case_report["query"] = case["query"]
                case_report["top_results"] = [
                    {
                        "rank": i + 1,
                        "score": chunk.score,
                        "document_name": chunk.document_name,
                        "content": chunk.content,
                        "retrieval_content": chunk.retrieval_content,
                    }
                    for i, chunk in enumerate(retrieved)
                ]
        # A malformed response/case must not prevent the rest of a batch report.
        except Exception as error:  # noqa: BLE001
            case_report["error"] = safe_error(error)
        case_reports.append(case_report)

    total = len(cases)
    valid = sum(1 for case in case_reports if "error" not in case)
    report: dict[str, Any] = {
        "schema_version": "1.0",
        "mode": args.mode,
        "case_count": total,
        "valid_case_count": valid,
        "chunk_count": chunk_count,
        "k_values": list(ks),
        "recall_at_k": {str(k): round(recall_hits[k] / max(valid, 1), 4) for k in ks},
        "mrr": round(reciprocal_rank_sum / max(valid, 1), 4),
        "numeric_case_count": numeric_cases,
        "numeric_hit_at_k": {
            str(k): round(numeric_hits[k] / max(numeric_cases, 1), 4) for k in ks
        },
        "trigger_numeric_hit_at_k": {
            str(k): round(trigger_numeric_hits[k] / max(numeric_cases, 1), 4)
            for k in ks
        },
        "unit_case_count": unit_cases,
        "unit_hit_at_k": {
            str(k): round(unit_hits[k] / max(unit_cases, 1), 4) for k in ks
        },
        "failed_case_ids_at_max_k": [
            case["id"]
            for case in case_reports
            if case.get("relevant_rank") is None and "error" not in case
        ],
        "error_case_ids": [case["id"] for case in case_reports if "error" in case],
        "elapsed_seconds": round(time.time() - started, 3),
        "contains_sensitive_content": bool(args.include_debug_content),
        "cases": case_reports,
    }
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Measure Recall@K, MRR, numeric hit rate, and unit hit rate."
    )
    parser.add_argument("--mode", choices=("local", "dify"), default="local")
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("-k", type=int, action="append", default=None)
    parser.add_argument(
        "--include-debug-content",
        action="store_true",
        help="Write queries and retrieved text to the report (may expose sensitive data).",
    )

    local = parser.add_argument_group("local mode")
    local.add_argument("--documents-dir", type=Path)
    local.add_argument("--entity", default="")
    local.add_argument("--currency", default="")
    local.add_argument("--unit", default="")
    local.add_argument("--parent-chunk-size", type=int, default=1800)
    local.add_argument("--child-chunk-size", type=int, default=450)

    dify = parser.add_argument_group("dify mode")
    dify.add_argument("--base-url", default="")
    dify.add_argument("--dataset-id", default="")
    dify.add_argument("--api-key-env", default="DIFY_DATASET_API_KEY")
    dify.add_argument(
        "--search-method",
        choices=(
            "hybrid_search",
            "semantic_search",
            "full_text_search",
            "keyword_search",
        ),
        default="hybrid_search",
    )
    dify.add_argument(
        "--weights",
        type=parse_weights,
        help="Legacy numeric weight or Dify weight JSON object, depending on server version.",
    )
    dify.add_argument("--reranking-enable", action="store_true")
    dify.add_argument(
        "--reranking-mode",
        choices=("reranking_model", "weighted_score"),
        default="reranking_model",
    )
    dify.add_argument("--reranking-provider", default="")
    dify.add_argument("--reranking-model", default="")
    dify.add_argument("--timeout", type=int, default=30)
    dify.add_argument("--retries", type=int, default=2)
    dify.add_argument(
        "--ca-bundle",
        type=Path,
        help="Optional corporate CA bundle in PEM format for internal HTTPS.",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    args.k = args.k or list(DEFAULT_KS)
    if any(k <= 0 for k in args.k):
        parser.error("every -k value must be greater than zero")
    if args.retries < 0:
        parser.error("--retries must not be negative")
    if args.timeout <= 0:
        parser.error("--timeout must be greater than zero")
    if args.output.resolve() == args.cases.resolve():
        parser.error("--output must not overwrite the cases file")
    if args.mode == "local" and not args.documents_dir:
        parser.error("--documents-dir is required in local mode")
    if args.mode == "dify" and (not args.base_url or not args.dataset_id):
        parser.error("--base-url and --dataset-id are required in dify mode")
    if args.mode == "dify" and not args.base_url.lower().startswith(
        ("http://", "https://")
    ):
        parser.error("--base-url must start with http:// or https://")
    if args.ca_bundle and not args.ca_bundle.is_file():
        parser.error("--ca-bundle must point to an existing PEM file")
    if args.mode == "dify" and args.reranking_enable:
        if args.reranking_mode == "reranking_model" and not (
            args.reranking_provider and args.reranking_model
        ):
            parser.error(
                "reranking_model mode requires --reranking-provider and --reranking-model"
            )
        if args.reranking_mode == "weighted_score" and not isinstance(
            args.weights, dict
        ):
            parser.error("weighted_score mode requires --weights with a JSON object")
    try:
        report = evaluate(args)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(
            json.dumps(
                {
                    key: report[key]
                    for key in (
                        "mode",
                        "case_count",
                        "recall_at_k",
                        "mrr",
                        "numeric_hit_at_k",
                        "unit_hit_at_k",
                        "failed_case_ids_at_max_k",
                        "trigger_numeric_hit_at_k",
                        "error_case_ids",
                        "contains_sensitive_content",
                    )
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        print(f"Report written to: {args.output.resolve()}")
        return 0 if not report["error_case_ids"] else 2
    # Keep the command-line contract stable: diagnostics go to stderr, not a traceback.
    except Exception as error:  # noqa: BLE001
        print(f"Evaluation failed: {safe_error(error)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
