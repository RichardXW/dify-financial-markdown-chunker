#!/usr/bin/env bash
set -euo pipefail

script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
python_command="${PYTHON_COMMAND:-python3}"

"$python_command" "$script_dir/evaluate_retrieval.py" \
  --mode local \
  --documents-dir "$script_dir/../examples/eval-docs" \
  --cases "$script_dir/../examples/evaluation_cases.json" \
  --output "$script_dir/../examples/evaluation_report.json" \
  -k 1 -k 3 -k 5 -k 10 \
  "$@"
