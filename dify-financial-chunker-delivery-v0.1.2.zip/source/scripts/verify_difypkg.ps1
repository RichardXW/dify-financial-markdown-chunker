param(
    [string]$PackagePath = (Join-Path $PSScriptRoot '..\..\dify-financial-chunker.difypkg'),
    [string]$ExpectedSha256 = ''
)

$ErrorActionPreference = 'Stop'
$resolved = (Resolve-Path -LiteralPath $PackagePath).Path
$hash = (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash

if ($ExpectedSha256 -and $hash -ne $ExpectedSha256.ToUpperInvariant()) {
    throw "SHA-256 mismatch. Expected $ExpectedSha256, got $hash"
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::OpenRead($resolved)
try {
    $entries = @($archive.Entries | ForEach-Object { $_.FullName })
    $required = @(
        'manifest.yaml',
        'main.py',
        'requirements.txt',
        'provider/financial_table_chunker.yaml',
        'provider/financial_table_chunker.py',
        'tools/financial_chunker.yaml',
        'tools/financial_chunker.py',
        'tools/financial_chunker_core.py'
    )
    $missing = @($required | Where-Object { $_ -notin $entries })
    if ($missing.Count) {
        throw "Package is missing required entries: $($missing -join ', ')"
    }

    $forbidden = @($entries | Where-Object {
        $_ -match '(^|/)(\.venv|__pycache__|tests|scripts|examples)(/|$)' -or
        $_ -match '\.(pyc|pyo)$' -or
        $_ -match '(^|/)requirements-dev\.txt$'
    })
    if ($forbidden.Count) {
        throw "Package contains development-only entries: $($forbidden -join ', ')"
    }
}
finally {
    $archive.Dispose()
}

Write-Output "Package structure OK ($($entries.Count) entries)"
Write-Output "SHA-256: $hash"
