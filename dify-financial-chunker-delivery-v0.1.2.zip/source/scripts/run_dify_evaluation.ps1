param(
    [Parameter(Mandatory = $true)][string]$BaseUrl,
    [Parameter(Mandatory = $true)][string]$DatasetId,
    [Parameter(Mandatory = $true)][string]$Cases,
    [Parameter(Mandatory = $true)][string]$Output,
    [ValidateSet('hybrid_search', 'semantic_search', 'full_text_search', 'keyword_search')]
    [string]$SearchMethod = 'hybrid_search',
    [switch]$EnableReranker,
    [ValidateSet('reranking_model', 'weighted_score')]
    [string]$RerankingMode = 'reranking_model',
    [string]$RerankingProvider = '',
    [string]$RerankingModel = '',
    [string]$Weights = '',
    [string]$CaBundle = '',
    [ValidateRange(1, 600)][int]$Timeout = 30,
    [ValidateRange(0, 10)][int]$Retries = 2,
    [string]$ApiKeyEnvironment = 'DIFY_DATASET_API_KEY',
    [string]$PythonCommand = 'python'
)

$ErrorActionPreference = 'Stop'
$evaluator = Join-Path $PSScriptRoot 'evaluate_retrieval.py'
$temporaryApiKey = $false
$exitCode = 1

if ($CaBundle -and -not (Test-Path -LiteralPath $CaBundle -PathType Leaf)) {
    throw "CA bundle not found: $CaBundle"
}
if ($EnableReranker -and $RerankingMode -eq 'reranking_model' -and
    (-not $RerankingProvider -or -not $RerankingModel)) {
    throw 'Reranking model mode requires -RerankingProvider and -RerankingModel.'
}
if ($EnableReranker -and $RerankingMode -eq 'weighted_score' -and -not $Weights) {
    throw 'Weighted-score mode requires -Weights containing a Dify JSON object.'
}

try {
    $apiKey = [Environment]::GetEnvironmentVariable($ApiKeyEnvironment, 'Process')
    if ([string]::IsNullOrWhiteSpace($apiKey)) {
        $secureKey = Read-Host 'Dify Dataset API Key' -AsSecureString
        $pointer = [IntPtr]::Zero
        try {
            $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
            $apiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
        }
        finally {
            if ($pointer -ne [IntPtr]::Zero) {
                [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
            }
        }
        if ([string]::IsNullOrWhiteSpace($apiKey)) {
            throw 'Dify Dataset API Key must not be empty.'
        }
        [Environment]::SetEnvironmentVariable($ApiKeyEnvironment, $apiKey, 'Process')
        $temporaryApiKey = $true
    }

    $arguments = @(
        $evaluator,
        '--mode', 'dify',
        '--base-url', $BaseUrl,
        '--dataset-id', $DatasetId,
        '--cases', $Cases,
        '--output', $Output,
        '--search-method', $SearchMethod,
        '--api-key-env', $ApiKeyEnvironment,
        '--timeout', $Timeout,
        '--retries', $Retries,
        '-k', '1', '-k', '3', '-k', '5', '-k', '10'
    )
    if ($Weights) {
        $arguments += @('--weights', $Weights)
    }
    if ($CaBundle) {
        $arguments += @('--ca-bundle', $CaBundle)
    }
    if ($EnableReranker) {
        $arguments += @('--reranking-enable', '--reranking-mode', $RerankingMode)
        if ($RerankingMode -eq 'reranking_model') {
            $arguments += @(
                '--reranking-provider', $RerankingProvider,
                '--reranking-model', $RerankingModel
            )
        }
    }

    & $PythonCommand @arguments
    $exitCode = $LASTEXITCODE
}
finally {
    if ($temporaryApiKey) {
        [Environment]::SetEnvironmentVariable($ApiKeyEnvironment, $null, 'Process')
    }
}

exit $exitCode
