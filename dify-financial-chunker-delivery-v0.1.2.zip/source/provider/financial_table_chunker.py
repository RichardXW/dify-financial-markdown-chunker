from typing import Any

from dify_plugin import ToolProvider


class FinancialTableChunkerProvider(ToolProvider):
    def _validate_credentials(self, credentials: dict[str, Any]) -> None:
        # This local processor has no credentials.
        return None
