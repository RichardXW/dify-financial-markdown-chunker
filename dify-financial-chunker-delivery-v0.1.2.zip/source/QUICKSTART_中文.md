# 金融混合 Markdown Chunker：交付与快速上手

## 交付内容

- `dify-financial-chunker.difypkg`：在 Dify 中通过本地文件安装。
- `dify-financial-chunker/`：插件完整源码。
- `scripts/evaluate_retrieval.py`：Recall@K、MRR、数字及单位命中率评测器。
- `scripts/run_local_evaluation.ps1`：一键运行本地离线评测。
- `scripts/run_dify_evaluation.ps1`：一键运行内网 Dify 真实检索评测。
- `scripts/*.sh`：Linux/macOS 对应的一键评测脚本。
- `scripts/verify_difypkg.ps1`：检查插件包结构和 SHA-256。
- `examples/`：脱敏样例文档、标注案例、案例 JSON Schema 和样例报告。
- `EVALUATION.md`：评测字段和指标说明。
- `DEPLOYMENT_CHECKLIST_中文.md`：内网上线前逐项检查。
- `CHANGELOG.md`：版本变更记录。
- `tests/`：Chunker 自动化测试。

## 第一步：安装插件

1. 打开 Dify 的“插件”页面。
2. 选择“安装插件”→“通过本地文件”。
3. 上传 `dify-financial-chunker.difypkg`。
4. 在 Knowledge Pipeline 中连接：文档提取节点 → 金融文档分块器 → Knowledge Base。
5. 将上游 Markdown 输出映射到插件的 `input_text`。
6. 将插件的 `result` 映射到 Knowledge Base 节点。

如果自建 Dify 开启了插件签名强制校验，内部未签名插件可能被拒绝。生产环境应按公司的 Dify 插件发布流程签名；开发环境是否允许未签名插件由管理员决定。

## 第二步：准备脱敏评测集

建议目录：

```text
D:\safe-eval\
├── markdown\
│   ├── annual_report_2024.md
│   └── product_document.md
└── evaluation_cases.json
```

案例格式参考 `examples/evaluation_cases.json`。不要将姓名、证件号、保单号、账户号、健康数据、未公开业务指标或 API Key 放进可外发材料。

## 第三步：运行本地评测

使用内置样例：

```powershell
cd dify-financial-chunker
.\scripts\run_local_evaluation.ps1
```

使用自己的脱敏数据：

```powershell
.\scripts\run_local_evaluation.ps1 `
  -DocumentsDir "D:\safe-eval\markdown" `
  -Cases "D:\safe-eval\evaluation_cases.json" `
  -Output "D:\safe-eval\local-report.json"
```

## 第四步：运行 Dify 真实评测

知识库完成索引后运行：

```powershell
.\scripts\run_dify_evaluation.ps1 `
  -BaseUrl "http://your-internal-dify.example.com" `
  -DatasetId "YOUR_DATASET_ID" `
  -Cases "D:\safe-eval\evaluation_cases.json" `
  -Output "D:\safe-eval\dify-report.json"
```

脚本会遮蔽输入 Dataset API Key，且不会把 Key 写入报告。

脚本在临时读取 Key 后会于运行结束时主动清除它；如果 Key 原本就由你设置在环境变量中，则保持不变。使用企业 CA 的 HTTPS：

```powershell
.\scripts\run_dify_evaluation.ps1 `
  -BaseUrl "https://your-internal-dify.example.com" `
  -DatasetId "YOUR_DATASET_ID" `
  -Cases "D:\safe-eval\evaluation_cases.json" `
  -Output "D:\safe-eval\dify-report.json" `
  -CaBundle "D:\certs\company-ca.pem" `
  -Retries 3 `
  -Timeout 60
```

## 第五步：解读结果

- `Recall@1`：第一条结果就是正确证据的比例。
- `Recall@5`：前五条中出现正确证据的比例。
- `MRR`：正确结果是否排在靠前位置。
- `Numeric Hit@K`：正确上下文和正确数字同时命中的比例。
- `Trigger Numeric Hit@K`：用于检索的 Child 是否真的含有预期数字；若 Dify API 不返回 Child 内容，该值只能作为 Parent 代理值。
- `Unit Hit@K`：正确上下文和单位同时命中的比例。

样例结果为 1.0 只表示执行链路正确，不能代表真实金融语料效果。真实评测建议至少使用 50 个开发案例，并另外保留 50～100 个不参与调参的测试案例。

## 上线前兼容性检查

- Dify 版本不低于 1.9.0；如果公司版本更旧，应先在隔离测试环境验证并调整 `minimum_dify_version`，不要直接改低后上线。
- Plugin Daemon 能通过内部 PyPI 镜像或缓存取得 `dify_plugin==0.5.1` 及依赖。
- 上游输出是真正保留表格行列的 Markdown；OCR 后表头错位不能靠 Chunker 自动恢复。
- 先用脱敏样例完成安装和索引，再在内网用真实文档评测。
- 生产发布遵循公司的插件签名、代码扫描、开源依赖和变更审批流程。

## 推荐 Dify 配置

- Parent Chunk：1800 字符起步。
- Child Chunk：450 字符起步。
- 检索：Hybrid Search。
- Top K：先测试 3、5、10。
- Reranker：有合适模型时启用，并用同一测试集进行 A/B 对比。

## 安全说明

评测器默认报告不包含问题、期望答案或召回原文。只有显式添加 `--include-debug-content` 才会写入原始内容；真实内部数据场景不要开启该参数，也不要把原始文档或调试报告发出内网。
