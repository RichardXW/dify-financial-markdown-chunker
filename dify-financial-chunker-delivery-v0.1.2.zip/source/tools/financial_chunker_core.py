from __future__ import annotations

import re
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation

TABLE_SEPARATOR = re.compile(r"^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$")
HEADING = re.compile(r"^\s{0,3}(#{1,6})\s+(.+?)\s*$")
LIST_ITEM = re.compile(r"^(?P<indent>\s*)(?P<marker>[-+*]|\d+[.)])\s+(?P<body>.+)$")
FENCE = re.compile(r"^\s*(```+|~~~+)")
NUMBER = re.compile(
    r"^\s*(?P<open>\()?\s*"
    r"(?:(?P<prefix_code>USD|HKD|CNY|RMB|EUR|GBP|JPY|US\$|HK\$)\s*)?"
    r"(?P<currency>[$¥￥£€])?\s*"
    r"(?P<number>[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)\s*"
    r"(?P<percent>%|％)?\s*"
    r"(?:(?P<suffix_code>USD|HKD|CNY|RMB|EUR|GBP|JPY)\s*)?"
    r"(?P<unit>(?:(?:千|万|百万|千万|亿|十亿)?"
    r"(?:人民币|美元|港元|欧元|英镑|日元|元)|"
    r"(?:人民币|美元|港元|欧元|英镑|日元)(?:千|万|百万|千万|亿|十亿)|"
    r"千|万|百万|千万|亿|十亿|个百分点|基点|倍|"
    r"thousand|million|billion|mn|bn|bps|k))?\s*"
    r"(?P<close>\))?\s*$",
    re.IGNORECASE,
)
INLINE_NUMBER = re.compile(
    r"(?<![\w.])\(?(?:(?:USD|HKD|CNY|RMB|EUR|GBP|JPY|US\$|HK\$)\s*)?"
    r"(?:[$¥￥£€]\s*)?[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?"
    r"\s*(?:%|％)?\s*(?:(?:USD|HKD|CNY|RMB|EUR|GBP|JPY)\s*)?"
    r"(?:(?:千|万|百万|千万|亿|十亿)?(?:人民币|美元|港元|欧元|英镑|日元|元)|"
    r"(?:人民币|美元|港元|欧元|英镑|日元)(?:千|万|百万|千万|亿|十亿)|"
    r"千|万|百万|千万|亿|十亿|个百分点|基点|倍|"
    r"thousand|million|billion|mn|bn|bps|k)?\)?(?![\w.])",
    re.IGNORECASE,
)

CURRENCY_SYMBOLS = {
    "$": "USD",
    "¥": "CNY/JPY",
    "￥": "CNY/JPY",
    "£": "GBP",
    "€": "EUR",
}
CURRENCY_CODES = {
    "USD": "USD",
    "US$": "USD",
    "HKD": "HKD",
    "HK$": "HKD",
    "CNY": "CNY",
    "RMB": "CNY",
    "EUR": "EUR",
    "GBP": "GBP",
    "JPY": "JPY",
}
CURRENCY_NAMES = {
    "人民币": "CNY",
    "美元": "USD",
    "港元": "HKD",
    "欧元": "EUR",
    "英镑": "GBP",
    "日元": "JPY",
}
MISSING_VALUES = {"", "-", "—", "–", "N/A", "n/a", "NA", "不适用"}


@dataclass
class Block:
    kind: str
    lines: list[str]
    heading_path: list[str]
    title_hint: str = ""
    context_hints: list[str] = field(default_factory=list)


def _split_markdown_row(line: str) -> list[str]:
    line = line.strip()
    line = line.removeprefix("|")
    line = line.removesuffix("|")
    sentinel = "\x00PIPE\x00"
    return [
        cell.replace(sentinel, "|").strip()
        for cell in line.replace(r"\|", sentinel).split("|")
    ]


def _is_table_start(lines: list[str], index: int) -> bool:
    return (
        index + 1 < len(lines)
        and "|" in lines[index]
        and bool(TABLE_SEPARATOR.match(lines[index + 1]))
    )


def _trim_lines(lines: list[str]) -> list[str]:
    cleaned = [line.rstrip() for line in lines]
    while cleaned and not cleaned[0].strip():
        cleaned.pop(0)
    while cleaned and not cleaned[-1].strip():
        cleaned.pop()
    return cleaned


def _parse_blocks(text: str) -> list[Block]:
    """Parse Markdown without flattening tables, lists, code, or heading hierarchy."""
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    headings: list[str] = []
    blocks: list[Block] = []
    text_buffer: list[str] = []
    recent_short_lines: list[str] = []

    def flush_text() -> None:
        nonlocal text_buffer, recent_short_lines
        cleaned = _trim_lines(text_buffer)
        if cleaned:
            blocks.append(Block("text", cleaned, headings.copy()))
            candidates = [
                re.sub(r"\s+", " ", candidate).strip()
                for candidate in cleaned
                if candidate.strip() and len(candidate.strip()) <= 160
            ]
            recent_short_lines = candidates[-6:]
        text_buffer = []

    i = 0
    while i < len(lines):
        heading = HEADING.match(lines[i])
        if heading:
            flush_text()
            level = len(heading.group(1))
            headings[:] = headings[: level - 1]
            headings.append(heading.group(2).strip())
            recent_short_lines = [heading.group(2).strip()]
            i += 1
            continue

        if _is_table_start(lines, i):
            flush_text()
            table_lines = [lines[i], lines[i + 1]]
            i += 2
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                table_lines.append(lines[i])
                i += 1
            blocks.append(
                Block(
                    "table",
                    table_lines,
                    headings.copy(),
                    recent_short_lines[-1] if recent_short_lines else "",
                    recent_short_lines.copy(),
                )
            )
            recent_short_lines = []
            continue

        fence = FENCE.match(lines[i])
        if fence:
            flush_text()
            delimiter = fence.group(1)
            marker = delimiter[0]
            code_lines = [lines[i]]
            i += 1
            while i < len(lines):
                code_lines.append(lines[i])
                if re.match(
                    rf"^\s*{re.escape(marker)}{{{len(delimiter)},}}\s*$", lines[i]
                ):
                    i += 1
                    break
                i += 1
            blocks.append(Block("code", code_lines, headings.copy()))
            recent_short_lines = []
            continue

        if LIST_ITEM.match(lines[i]):
            flush_text()
            list_lines: list[str] = []
            while i < len(lines):
                line = lines[i]
                if LIST_ITEM.match(line) or (line.strip() and line[:1].isspace()):
                    list_lines.append(line)
                    i += 1
                    continue
                if (
                    not line.strip()
                    and i + 1 < len(lines)
                    and LIST_ITEM.match(lines[i + 1])
                ):
                    list_lines.append(line)
                    i += 1
                    continue
                break
            blocks.append(Block("list", _trim_lines(list_lines), headings.copy()))
            recent_short_lines = []
            continue

        text_buffer.append(lines[i])
        i += 1

    flush_text()
    return blocks


def _clean_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def _strip_numeric_markup(raw: str) -> str:
    value = re.sub(r"<sup\b[^>]*>.*?</sup>", "", raw, flags=re.IGNORECASE)
    value = re.sub(
        r"(?:\[(?:\d+|[a-z])\]|(?<=\d)\((?:\d+|[a-z])\)|[⁰¹²³⁴⁵⁶⁷⁸⁹]+)\s*$",
        "",
        value,
        flags=re.IGNORECASE,
    )
    value = value.strip().replace("−", "-").replace("﹣", "-")
    wrappers = (("**", "**"), ("__", "__"), ("`", "`"))
    changed = True
    while changed:
        changed = False
        for opening, closing in wrappers:
            if value.startswith(opening) and value.endswith(closing):
                value = value[len(opening) : -len(closing)].strip()
                changed = True
    return re.sub(r"[†‡*]+$", "", value).strip()


def _currency_from_text(value: str) -> str | None:
    upper = value.upper().strip()
    if upper in CURRENCY_CODES:
        return CURRENCY_CODES[upper]
    for name, code in CURRENCY_NAMES.items():
        if name in value:
            return code
    return None


def _numeric_aliases(raw: str) -> tuple[str | None, list[str], str | None]:
    value = _strip_numeric_markup(raw)
    match = NUMBER.match(value)
    if not match:
        return None, [], None

    number = match.group("number").replace(",", "")
    negative = bool(match.group("open") and match.group("close"))
    try:
        decimal = Decimal(number)
        if negative:
            decimal = -abs(decimal)
        normalized = format(decimal, "f")
        if "." in normalized:
            normalized = normalized.rstrip("0").rstrip(".")
    except InvalidOperation:
        return None, [], None

    percent = bool(match.group("percent"))
    aliases = [normalized]
    if percent:
        aliases.append(f"{normalized}%")
    if decimal == decimal.to_integral_value():
        aliases.append(f"{int(decimal):,}")
    code = match.group("prefix_code") or match.group("suffix_code") or ""
    currency = (
        CURRENCY_CODES.get(code.upper())
        or CURRENCY_SYMBOLS.get(match.group("currency") or "")
        or _currency_from_text(match.group("unit") or "")
    )
    return normalized, list(dict.fromkeys(aliases)), currency


def _numeric_unit(raw: str) -> str | None:
    match = NUMBER.match(_strip_numeric_markup(raw))
    if not match:
        return None
    if match.group("percent"):
        return "%"
    return match.group("unit")


def _inline_numeric_alias_line(text: str) -> str:
    aliases: list[str] = []
    for match in INLINE_NUMBER.finditer(text):
        raw = match.group(0).strip()
        normalized, values, _ = _numeric_aliases(raw)
        informative = (
            any(
                token in raw
                for token in (",", ".", "%", "％", "(", "$", "¥", "￥", "£", "€")
            )
            or raw.startswith(("+", "-", "−", "﹣"))
            or bool(
                re.search(
                    r"USD|HKD|CNY|RMB|EUR|GBP|JPY|百万|千万|十亿|million|billion|mn|bn|bps|基点",
                    raw,
                    re.IGNORECASE,
                )
            )
        )
        if normalized is not None and informative:
            aliases.extend([raw, *values])
    unique = list(dict.fromkeys(aliases))
    return f"检索数值别名：{'；'.join(unique)}" if unique else ""


def _context_prefix(
    document_name: str, entity: str, heading_path: list[str], title: str = ""
) -> list[str]:
    values: list[str] = []
    if document_name:
        values.append(f"文档：{document_name}")
    if entity:
        values.append(f"主体：{entity}")
    if heading_path:
        values.append(f"章节：{' > '.join(heading_path)}")
    if title and title not in heading_path:
        values.append(f"表名：{title}")
    return values


def _effective_table_title(block: Block) -> str:
    hints = block.context_hints or ([block.title_hint] if block.title_hint else [])
    for candidate in reversed(hints):
        hint = _clean_text(candidate)
        if not hint or re.match(
            r"^(单位|币种|口径|注\d*|备注|数据来源|来源)\s*[：:]", hint
        ):
            continue
        if (
            LIST_ITEM.match(hint)
            or len(hint) > 100
            or re.search(r"[。！？!?；;]$", hint)
        ):
            continue
        return re.sub(r"^(?:\*\*|__)(.+)(?:\*\*|__)$", r"\1", hint)
    return block.heading_path[-1] if block.heading_path else ""


def _table_row_children(
    headers: list[str],
    row: list[str],
    prefix: list[str],
    entity: str,
    currency: str,
    unit: str,
) -> list[str]:
    width = len(headers)
    row += [""] * (width - len(row))
    metric = _clean_text(row[0])
    if not metric:
        return []

    dimension_name = _clean_text(headers[0]) or "指标"
    children: list[str] = []
    row_pairs: list[str] = []
    for column_index in range(1, width):
        raw = _clean_text(row[column_index])
        if raw in MISSING_VALUES:
            continue
        period = _clean_text(headers[column_index]) or f"列{column_index + 1}"
        row_pairs.append(f"{period}={raw}")
        normalized, aliases, symbol_currency = _numeric_aliases(raw)
        fact = prefix + [
            f"{dimension_name}：{metric}",
            f"期间或维度：{period}",
            f"数值原文：{raw}",
        ]
        if normalized is not None:
            fact.extend(
                [f"标准化数值：{normalized}", f"数值别名：{'；'.join(aliases)}"]
            )
        effective_currency = (
            currency or symbol_currency
            if symbol_currency == "CNY/JPY"
            else symbol_currency or currency
        )
        if effective_currency:
            fact.append(f"币种：{effective_currency}")
        explicit_unit = _numeric_unit(raw)
        effective_unit = explicit_unit or unit
        if effective_unit:
            fact.append(f"单位：{effective_unit}")
        subject = f"{entity} " if entity else ""
        suffix = (
            effective_unit
            if effective_unit and effective_unit != "%" and not explicit_unit
            else ""
        )
        fact.append(f"事实：{subject}{period}的{metric}为{raw}{suffix}。")
        children.append("\n".join(fact))

    if row_pairs:
        children.insert(
            0,
            "\n".join(
                prefix
                + [
                    f"表格行：{dimension_name}={metric}",
                    f"各期间数值：{'；'.join(row_pairs)}",
                    f"比较事实：{metric}，{'；'.join(row_pairs)}。",
                ]
            ),
        )
    elif len(row) == 1:
        children.append("\n".join(prefix + [f"{dimension_name}：{metric}"]))
    return children


def _table_chunks(
    block: Block,
    document_name: str,
    entity: str,
    currency: str,
    unit: str,
    parent_limit: int,
) -> list[dict[str, object]]:
    parsed = [_split_markdown_row(line) for line in block.lines]
    if len(parsed) < 3:
        return []
    headers = parsed[0]
    data_rows = parsed[2:]
    width = max(len(headers), *(len(row) for row in data_rows))
    headers += [f"列{i + 1}" for i in range(len(headers), width)]

    title = _effective_table_title(block)
    prefix = _context_prefix(document_name, entity, block.heading_path, title)
    effective_currency = currency
    effective_unit = unit
    hints = block.context_hints or ([block.title_hint] if block.title_hint else [])
    for raw_hint in hints:
        hint = _clean_text(raw_hint)
        unit_match = re.match(r"^单位\s*[：:]\s*(.+)$", hint)
        currency_match = re.match(r"^币种\s*[：:]\s*(.+)$", hint)
        context_match = re.match(
            r"^(?:口径|注\d*|备注|数据来源|来源)\s*[：:]\s*(.+)$", hint
        )
        if unit_match:
            parsed_unit = unit_match.group(1).strip()
            effective_unit = effective_unit or parsed_unit
            effective_currency = (
                effective_currency or _currency_from_text(parsed_unit) or ""
            )
            prefix.append(f"表格单位：{parsed_unit}")
        elif currency_match:
            raw_currency = currency_match.group(1).strip()
            effective_currency = (
                effective_currency
                or _currency_from_text(raw_currency)
                or raw_currency.upper()
            )
            prefix.append(f"表格币种：{raw_currency}")
        elif context_match:
            prefix.append(f"表格上下文：{hint}")
    if effective_currency:
        prefix.append(f"默认币种：{effective_currency}")
    if effective_unit:
        prefix.append(f"默认单位：{effective_unit}")

    header_lines = block.lines[:2]
    batches: list[list[tuple[str, list[str]]]] = []
    current: list[tuple[str, list[str]]] = []
    current_length = len("\n".join(prefix + header_lines))
    for raw_line, row in zip(block.lines[2:], data_rows):
        projected = current_length + len(raw_line) + 1
        if current and projected > parent_limit:
            batches.append(current)
            current = []
            current_length = len("\n".join(prefix + header_lines))
        current.append((raw_line, row))
        current_length += len(raw_line) + 1
    if current:
        batches.append(current)

    output: list[dict[str, object]] = []
    for batch_index, batch in enumerate(batches, start=1):
        batch_prefix = prefix.copy()
        if len(batches) > 1:
            batch_prefix.append(f"表格分片：{batch_index}/{len(batches)}（表头已重复）")
        children: list[str] = []
        for _, row in batch:
            children.extend(
                _table_row_children(
                    headers,
                    row.copy(),
                    prefix,
                    entity,
                    effective_currency,
                    effective_unit,
                )
            )
        if not children:
            continue
        parent_lines = batch_prefix + ["", *header_lines, *(line for line, _ in batch)]
        output.append(
            {
                "parent_content": "\n".join(parent_lines).strip(),
                "child_contents": children,
                "files": [],
            }
        )
    return output


def _split_sentences(text: str, limit: int) -> list[str]:
    text = text.strip()
    if not text:
        return []
    sentences = [
        item.strip()
        for item in re.split(r"(?<=[。！？!?；;])\s*|\.(?!\d)\s+|\n\s*\n", text)
        if item.strip()
    ]
    chunks: list[str] = []
    current = ""
    for sentence in sentences:
        pieces = (
            [sentence[i : i + limit] for i in range(0, len(sentence), limit)]
            if len(sentence) > limit
            else [sentence]
        )
        for piece in pieces:
            if current and len(current) + len(piece) + 1 > limit:
                chunks.append(current)
                current = piece
            else:
                current = f"{current}\n{piece}".strip()
    if current:
        chunks.append(current)
    return chunks


def _list_children(lines: list[str], child_limit: int) -> list[str]:
    records: list[tuple[int, str, list[str]]] = []
    for line in lines:
        match = LIST_ITEM.match(line)
        if match:
            indent_text = match.group("indent").replace("\t", "    ")
            records.append(
                (len(indent_text), match.group("body").strip(), [line.strip()])
            )
        elif records and line.strip():
            records[-1][2].append(line.strip())

    children: list[str] = []
    stack: list[tuple[int, str]] = []
    for indent, body, raw_lines in records:
        while stack and stack[-1][0] >= indent:
            stack.pop()
        item = "\n".join(raw_lines).strip()
        path_prefix = ""
        if stack:
            labels = [*(value for _, value in stack), _list_label(body)]
            path = " > ".join(labels)
            if len(path) > 160:
                path = f"{labels[0]} > … > {labels[-1]}"
                path = path[:160].rstrip()
            path_prefix = f"列表路径：{path}"
        content_limit = max(20, child_limit - len(path_prefix) - 1)
        for piece in _split_sentences(item, content_limit):
            children.append(f"{path_prefix}\n{piece}".strip())
        stack.append((indent, _list_label(body)))
    return children


def _list_label(body: str) -> str:
    label = re.split(r"[。！？!?；;：:]", _clean_text(body), maxsplit=1)[0]
    return f"{label[:57]}…" if len(label) > 60 else label


def _code_children(lines: list[str], child_limit: int) -> list[str]:
    content = "\n".join(lines).strip()
    if len(content) <= child_limit:
        return [content] if content else []
    opening = lines[0].strip() if lines else "```"
    opening_match = FENCE.match(opening)
    delimiter = opening_match.group(1) if opening_match else "```"
    closing_match = (
        re.match(rf"^\s*{re.escape(delimiter[0])}{{{len(delimiter)},}}\s*$", lines[-1])
        if len(lines) > 1
        else None
    )
    has_closing = bool(closing_match)
    closing = lines[-1].strip() if has_closing else delimiter
    body = lines[1:-1] if has_closing else lines[1:]
    available = max(80, child_limit - len(opening) - len(closing) - 2)
    pieces: list[str] = []
    current: list[str] = []
    current_length = 0
    for line in body:
        line_parts = (
            [line[i : i + available] for i in range(0, len(line), available)]
            if len(line) > available
            else [line]
        )
        for line_part in line_parts:
            if current and current_length + len(line_part) + 1 > available:
                pieces.append(f"{opening}\n{chr(10).join(current)}\n{closing}")
                current = []
                current_length = 0
            current.append(line_part)
            current_length += len(line_part) + 1
    if current:
        pieces.append(f"{opening}\n{chr(10).join(current)}\n{closing}")
    return pieces or [f"{opening}\n{closing}"]


def _pack_parent_child_groups(
    children: list[str], prefix: list[str], parent_limit: int
) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    group: list[str] = []
    length = len("\n".join(prefix))

    def append_group(items: list[str]) -> None:
        parent = "\n\n".join([*prefix, *items]).strip()
        enriched: list[str] = []
        for item in items:
            alias_line = _inline_numeric_alias_line(item)
            enriched.append("\n".join([*prefix, item, alias_line]).strip())
        output.append(
            {"parent_content": parent, "child_contents": enriched, "files": []}
        )

    for child in children:
        if group and length + len(child) + 2 > parent_limit:
            append_group(group)
            group = []
            length = len("\n".join(prefix))
        group.append(child)
        length += len(child) + 2
    if group:
        append_group(group)
    return output


def build_parent_child_chunks(
    text: str,
    *,
    document_name: str = "",
    entity: str = "",
    currency: str = "",
    unit: str = "",
    parent_chunk_size: int = 1800,
    child_chunk_size: int = 450,
    text_chunk_size: int | None = None,
) -> dict[str, object]:
    """Build Dify Parent-Child chunks from a mixed Markdown document."""
    if text_chunk_size is not None:
        child_chunk_size = int(text_chunk_size)
    child_limit = max(200, min(int(child_chunk_size), 1500))
    parent_limit = max(child_limit, min(int(parent_chunk_size), 8000))
    currency = currency.upper()
    output: list[dict[str, object]] = []

    for block in _parse_blocks(text):
        if block.kind == "table":
            output.extend(
                _table_chunks(
                    block,
                    document_name,
                    entity,
                    currency,
                    unit,
                    parent_limit,
                )
            )
            continue

        prefix = _context_prefix(document_name, entity, block.heading_path)
        content = "\n".join(block.lines).strip()
        if block.kind == "list":
            children = _list_children(block.lines, child_limit)
        elif block.kind == "code":
            children = _code_children(block.lines, child_limit)
        else:
            children = _split_sentences(content, child_limit)
        output.extend(_pack_parent_child_groups(children, prefix, parent_limit))

    return {"parent_mode": "paragraph", "parent_child_chunks": output}
