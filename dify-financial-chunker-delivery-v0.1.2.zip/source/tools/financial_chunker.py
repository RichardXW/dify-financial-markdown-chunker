from collections.abc import Generator
from typing import Any

from dify_plugin import Tool
from dify_plugin.entities.tool import ToolInvokeMessage
from tools.financial_chunker_core import build_parent_child_chunks


class FinancialChunkerTool(Tool):
    def _invoke(
        self, tool_parameters: dict[str, Any]
    ) -> Generator[ToolInvokeMessage, None, None]:
        text = str(tool_parameters.get("input_text") or "").strip()
        if not text:
            yield self.create_text_message("input_text must not be empty")
            return

        result = build_parent_child_chunks(
            text,
            document_name=str(tool_parameters.get("document_name") or ""),
            entity=str(tool_parameters.get("entity") or ""),
            currency=str(tool_parameters.get("default_currency") or ""),
            unit=str(tool_parameters.get("default_unit") or ""),
            parent_chunk_size=int(tool_parameters.get("parent_chunk_size") or 1800),
            child_chunk_size=int(tool_parameters.get("child_chunk_size") or 450),
        )
        yield self.create_json_message({"result": result})
