# Recall@K 与数字命中率评测

## 指标含义

- **Recall@K**：前 K 个召回结果中至少有一个包含期望证据的案例比例。
- **MRR**：第一个正确证据排名倒数的平均值；正确结果越靠前越接近 1。
- **Numeric Hit@K**：带 `expected_value` 的案例中，前 K 个结果同时命中正确上下文和数值的比例。
- **Trigger Numeric Hit@K**：相关 Parent 被召回时，触发检索的 Child（API 返回 Child 时）是否包含预期数值。用于判断“表格里的数字是否真正参与了召回”，而不只是数字碰巧存在于 Parent。
- **Unit Hit@K**：带 `expected_unit` 的案例中，前 K 个结果同时命中正确上下文和单位的比例。

评测器使用 `must_contain`、`any_of` 和 `expected_document` 判断证据是否相关。只有相关证据包含预期数值时才算数字命中，避免某个无关表格碰巧含有相同数字。

## 准备测试集

复制 `examples/evaluation_cases.json`，字段结构也可用 `examples/evaluation_cases.schema.json` 校验。每个案例格式如下：

```json
{
  "id": "CASE_001",
  "query": "2024 年新业务价值是多少？",
  "expected_document": "annual_report_2024.md",
  "must_contain": ["新业务价值", "2024"],
  "any_of": ["AIA Group", "集团"],
  "expected_value": "2460",
  "expected_unit": "百万美元"
}
```

- `id`、`query` 必填。
- `must_contain`：正确证据必须包含全部词语。
- `any_of`：正确证据至少包含其中一个词语。
- `expected_document`：可选，用文件名限制正确来源。
- `expected_value`：可选；支持 `2,460` 与 `2460`、`12.8%` 与 `12.8％` 的规范化比较。
- `expected_unit`：可选。

不要把 API Key 写入 JSON、源码或命令行参数。

## 模式一：本地离线评测

```powershell
python scripts\evaluate_retrieval.py `
  --mode local `
  --documents-dir D:\safe-eval\markdown `
  --cases D:\safe-eval\evaluation_cases.json `
  --output D:\safe-eval\local-report.json
```

本地模式使用确定性的 BM25 风格检索测试 Chunker。它适合快速比较不同分块参数，但不能替代 Dify 中真实的 Embedding、全文索引和 Reranker 测试。
本地实现按 Child 建索引、按 Parent 返回并去重，以贴近 Dify 的父子检索行为。

调整分块参数：

```powershell
python scripts\evaluate_retrieval.py `
  --mode local `
  --documents-dir D:\safe-eval\markdown `
  --cases D:\safe-eval\evaluation_cases.json `
  --output D:\safe-eval\local-1800-450.json `
  --parent-chunk-size 1800 `
  --child-chunk-size 450
```

## 模式二：Dify 知识库真实评测

PowerShell 7 可在当前会话中设置 Dataset API Key，输入会被遮蔽：

```powershell
$env:DIFY_DATASET_API_KEY = Read-Host "Dify Dataset API Key" -MaskInput
```

Windows PowerShell 5.1 建议直接使用 `scripts/run_dify_evaluation.ps1`；它使用兼容的 SecureString 输入，并在结束后清除脚本临时设置的 Key。不要把 Key 直接写进命令历史。

然后运行：

```powershell
python scripts\evaluate_retrieval.py `
  --mode dify `
  --base-url http://your-internal-dify.example.com `
  --dataset-id YOUR_DATASET_ID `
  --cases D:\safe-eval\evaluation_cases.json `
  --output D:\safe-eval\dify-report.json `
  --search-method hybrid_search `
  -k 1 -k 3 -k 5 -k 10
```

Dify 模式调用：

```text
POST /v1/datasets/{dataset_id}/retrieve
```

如果要测试 Reranker，除了 `--reranking-enable`，还需按下例提供内部实例的 provider 和 model 标识。不同 Dify 版本和检索配置对 `weights` 的解释可能不同，建议先不传，再按内部实例的 API 规范添加 `--weights`。

使用 Reranker 模型时必须给出 Dify 内部实际的 provider 和 model 标识：

```powershell
python scripts\evaluate_retrieval.py `
  --mode dify `
  --base-url https://your-internal-dify.example.com `
  --dataset-id YOUR_DATASET_ID `
  --cases D:\safe-eval\evaluation_cases.json `
  --output D:\safe-eval\dify-reranked-report.json `
  --reranking-enable `
  --reranking-mode reranking_model `
  --reranking-provider YOUR_PROVIDER_ID `
  --reranking-model YOUR_MODEL_ID
```

较新的 Dify 版本可使用 JSON 形式的 weighted-score 配置；较早版本可能使用 `0.7` 这类数值权重。评测器两者都接受，但最终格式必须以公司内部 Dify 版本的 API schema 为准：

```powershell
--weights '{"weight_type":"semantic_first"}'
```

内网 HTTPS 使用企业 CA 时传入 PEM CA bundle；瞬时的 `429/5xx` 默认重试 2 次：

```powershell
--ca-bundle D:\certs\company-ca.pem --timeout 60 --retries 3
```

一键脚本 `scripts/run_dify_evaluation.ps1` 支持同名参数。Linux/macOS 可使用：

```bash
export DIFY_DATASET_API_KEY='dataset-...'
./scripts/run_dify_evaluation.sh \
  https://your-internal-dify.example.com \
  YOUR_DATASET_ID \
  /safe-eval/evaluation_cases.json \
  /safe-eval/dify-report.json
```

如果 Dify 的 `/retrieve` 响应没有返回 Child 文本，`Trigger Numeric Hit@K` 会退化为 Parent 数值命中的代理指标；这时应结合 Dify 控制台的命中详情抽样核对触发 Child。

## 安全报告

默认报告只包含：

- 汇总指标；
- 案例 ID；
- 正确证据排名；
- 是否命中数值/单位；
- 错误类型。

默认不包含 query、expected value 或召回文本，可将报告交给外部协作者分析。

`--include-debug-content` 会把问题和召回原文写入报告，仅允许在经批准的内网位置使用，不要把该报告发出内网。

## 推荐基线

PoC 阶段可以先使用以下门槛：

- Recall@5 ≥ 0.90
- Numeric Hit@5 ≥ 0.95
- Trigger Numeric Hit@5 ≥ 0.90（仅在能取得 Child 命中内容时）
- Unit Hit@5 ≥ 0.98
- MRR ≥ 0.75

正式上线阈值必须根据友邦内部风险评级、文档类型和人工复核要求确定，不能把以上建议当作合规标准。
