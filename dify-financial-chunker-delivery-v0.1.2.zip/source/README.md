# Financial Table Chunker for Dify

面向金融、保险长文档的 Dify Knowledge Pipeline Tool 插件。它把标题、长正文、嵌套列表、表格和代码块混合存在的 Markdown 转换成 Dify 官方 `multimodal-Parent-Child` 结构。

## 解决的问题

- 完整表格作为 Parent 保留标题、章节、单位和来源语境。
- 每个“指标 × 期间”生成独立 Child，避免表头与数值分离。
- 每行额外生成跨期间比较 Child，支持同比、趋势和年度对比问题。
- 保留数值原文，并生成去千分位后的规范化值和别名。
- 支持括号负数、百分比、常见币种符号/代码、Markdown 粗体/行内代码、脚注及 `million`/`bn`/`百万`/`亿` 等常用单位。
- 自动继承表格前的表名、币种、单位、口径、备注和数据来源。
- 金融长文按标题层级、段落和句子形成父子窗口。
- 列表保持独立结构，列表项作为检索 Child，不与相邻段落粘连。
- 长表格按行安全分片，并在每个 Parent 中重复表头。
- 普通正文、列表、代码块和表格不会相互混切。

## Dify 中使用

1. 安装 Dify 插件 CLI。
2. 在本目录执行：

   ```bash
   dify plugin package .
   ```

3. 在 Dify 的“插件”页面上传生成的 `.difypkg`。
4. 新建 Knowledge Pipeline：文档提取节点 → 本插件 → Knowledge Base 节点。
5. 将提取出的 Markdown 文本映射到 `input_text`。
6. Knowledge Base 节点选择本插件的 `result`；Dify 会按 Parent-Child 结构建立索引。

生产环境建议使用能保留表格结构的上游解析器，例如 PaddleOCR PP-StructureV3、Unstructured、Docling 或企业文档解析服务。

## 本地测试

核心模块不依赖 Dify SDK：

```bash
python -m unittest discover -s tests -v
```

开发环境可运行静态检查：

```bash
python -m pip install -r requirements-dev.txt
python -m ruff check . --exclude .venv
```

## 检索效果评测

仓库包含同时支持本地 Chunk 检索和内网 Dify 知识库 API 的评测器：

```bash
python scripts/evaluate_retrieval.py --mode local --documents-dir examples/eval-docs --cases examples/evaluation_cases.json --output examples/evaluation_report.json
```

指标包括 Recall@1/3/5/10、MRR、Parent 数字命中率、触发 Child 数字命中率和单位命中率。默认报告不写入问题、答案或召回原文。完整字段、Dify 模式命令和脱敏要求见 `EVALUATION.md`。

## 当前输入边界

本插件直接处理混合 Markdown，不负责 PDF OCR。复杂合并表头、跨页续表应由上游解析器恢复，或在后续版本中通过结构化 JSON 输入接入。

插件运行器为 Python 3.12，`manifest.yaml` 声明最低 Dify 1.9.0，并固定使用已验证的 `dify_plugin==0.5.1`。隔离网环境应确保 Plugin Daemon 能访问包含该版本及其依赖的内部 PyPI 镜像或缓存。
