import argparse
import json
import sys
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import MagicMock, patch

PROJECT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_DIR / "scripts"))

import evaluate_retrieval as evaluator


class EvaluationTests(unittest.TestCase):
    def test_weights_accept_legacy_number_and_current_json(self):
        self.assertEqual(evaluator.parse_weights("0.7"), 0.7)
        self.assertEqual(
            evaluator.parse_weights('{"weight_type":"semantic_first"}'),
            {"weight_type": "semantic_first"},
        )

    def test_numeric_match_uses_complete_tokens(self):
        case = evaluator.RetrievedChunk(content="2024 年新业务价值为 12,460。")
        self.assertFalse(evaluator.contains_value(case, "2460"))
        self.assertTrue(evaluator.contains_value(case, "12460"))
        self.assertFalse(evaluator.contains_expected(case, {"must_contain": ["2460"]}))

    def test_numeric_normalization_keeps_large_integer_precision(self):
        value = "12,345,678,901,234,567"
        self.assertEqual(evaluator.normalize_number(value), "12345678901234567")

    def test_numeric_suffix_is_parsed(self):
        self.assertEqual(evaluator.numeric_tokens("value was 1.20bn"), {"1.2"})
        self.assertEqual(evaluator.numeric_tokens("下降 (12.8%)"), {"-12.8%"})
        self.assertEqual(evaluator.numeric_tokens("调整值 (-12.8%)"), {"-12.8%"})

    def test_local_retriever_deduplicates_parent_evidence(self):
        chunks = [
            evaluator.RetrievedChunk(
                content="父块 A",
                retrieval_content="新业务价值 2024 2,460",
                evidence_id="parent-a",
            ),
            evaluator.RetrievedChunk(
                content="父块 A",
                retrieval_content="新业务价值 2023 2,180",
                evidence_id="parent-a",
            ),
            evaluator.RetrievedChunk(
                content="父块 B",
                retrieval_content="新业务价值增长原因",
                evidence_id="parent-b",
            ),
        ]
        results = evaluator.BM25Retriever(chunks).search("新业务价值", 10)
        self.assertEqual(
            {item.evidence_id for item in results}, {"parent-a", "parent-b"}
        )
        self.assertEqual(len(results), 2)

    def test_dify_response_and_retry_are_handled_without_network(self):
        response = MagicMock()
        response.read.return_value = json.dumps(
            {
                "records": [
                    {
                        "id": "record-1",
                        "score": 0.91,
                        "segment": {
                            "id": "segment-1",
                            "content": "父块内容 2,460",
                            "document": {"name": "annual-report.md"},
                            "child_chunks": [{"content": "新业务价值 2,460"}],
                        },
                    }
                ]
            },
            ensure_ascii=False,
        ).encode("utf-8")
        context_manager = MagicMock()
        context_manager.__enter__.return_value = response
        retryable = urllib.error.HTTPError(
            "https://dify.example/v1/datasets/test/retrieve", 503, "busy", {}, None
        )
        args = argparse.Namespace(
            api_key_env="TEST_DIFY_KEY",
            base_url="https://dify.example",
            dataset_id="test",
            search_method="hybrid_search",
            reranking_enable=False,
            weights=None,
            ca_bundle=None,
            retries=1,
            timeout=2,
        )
        with (
            patch.dict("os.environ", {"TEST_DIFY_KEY": "dummy"}),
            patch.object(
                evaluator.urllib.request,
                "urlopen",
                side_effect=[retryable, context_manager],
            ) as urlopen,
            patch.object(evaluator.time, "sleep"),
        ):
            results = evaluator.dify_search({"query": "新业务价值"}, args, 5)

        self.assertEqual(urlopen.call_count, 2)
        self.assertEqual(results[0].document_name, "annual-report.md")
        self.assertEqual(results[0].content, "父块内容 2,460")
        self.assertEqual(results[0].retrieval_content, "新业务价值 2,460")


if __name__ == "__main__":
    unittest.main()
