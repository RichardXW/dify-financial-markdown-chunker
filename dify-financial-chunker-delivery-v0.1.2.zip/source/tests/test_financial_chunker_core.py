import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.financial_chunker_core import build_parent_child_chunks

SAMPLE = """# 主要财务指标

单位：百万美元

| 指标 | 2023 | 2024 |
| --- | ---: | ---: |
| 保险服务收入 | 12,450 | 13,280 |
| 新业务价值 | 2,180 | 2,460 |
| 新业务价值增长率 | 5.0% | 12.8% |
"""

MIXED_SAMPLE = """# 2024 年度报告

## 经营回顾

集团在报告期内持续推进高质量增长。新业务价值同比增长 12.8%，主要受代理人渠道推动。

主要驱动因素包括：

- 代理人渠道新业务价值增长 15.2%
  - 中国香港市场保持增长
  - 东南亚市场改善
- 银保渠道年化新保费达到 1,250 百万美元
- 产品组合向长期储蓄及保障业务倾斜

## 主要财务指标

单位：百万美元

| 指标 | 2022 | 2023 | 2024 |
| --- | ---: | ---: | ---: |
| 保险服务收入 | 11,900 | 12,450 | 13,280 |
| 新业务价值 | 1,950 | 2,180 | 2,460 |

## 风险提示

利率、汇率以及资本市场波动可能影响未来业绩。该说明不构成盈利预测。
"""


class FinancialChunkerTests(unittest.TestCase):
    def test_emits_dify_parent_child_shape(self):
        result = build_parent_child_chunks(
            SAMPLE,
            document_name="AIA 2024 Annual Report",
            entity="AIA Group",
            currency="USD",
            unit="百万",
        )
        self.assertEqual(result["parent_mode"], "paragraph")
        self.assertTrue(result["parent_child_chunks"])
        for chunk in result["parent_child_chunks"]:
            self.assertIsInstance(chunk["parent_content"], str)
            self.assertTrue(chunk["parent_content"])
            self.assertIsInstance(chunk["child_contents"], list)
            self.assertTrue(chunk["child_contents"])
            self.assertTrue(
                all(
                    isinstance(child, str) and child
                    for child in chunk["child_contents"]
                )
            )
            self.assertEqual(chunk["files"], [])

    def test_creates_exact_numeric_alias(self):
        result = build_parent_child_chunks(
            SAMPLE, entity="AIA Group", currency="USD", unit="百万"
        )
        children = "\n".join(
            child
            for parent in result["parent_child_chunks"]
            for child in parent["child_contents"]
        )
        self.assertIn("标准化数值：2460", children)
        self.assertIn("数值别名：2460；2,460", children)
        self.assertIn("期间或维度：2024", children)
        self.assertIn("指标：新业务价值", children)

    def test_parent_preserves_whole_table(self):
        result = build_parent_child_chunks(SAMPLE)
        parents = "\n".join(
            item["parent_content"] for item in result["parent_child_chunks"]
        )
        self.assertIn("| 新业务价值 | 2,180 | 2,460 |", parents)

    def test_table_inherits_unit_line(self):
        result = build_parent_child_chunks(SAMPLE)
        children = "\n".join(
            child
            for parent in result["parent_child_chunks"]
            for child in parent["child_contents"]
        )
        self.assertIn("表格单位：百万美元", children)
        self.assertIn("单位：百万美元", children)

    def test_accounting_negative_number(self):
        sample = """| 指标 | 2024 |
| --- | ---: |
| 净亏损 | (1,250) |
| 净亏损（无千分位） | (1250) |
| 带脚注值 | 2460(1) |
"""
        result = build_parent_child_chunks(sample)
        children = "\n".join(result["parent_child_chunks"][0]["child_contents"])
        self.assertIn("标准化数值：-1250", children)
        self.assertIn("标准化数值：2460", children)

    def test_mixed_markdown_preserves_heading_context(self):
        result = build_parent_child_chunks(
            MIXED_SAMPLE,
            document_name="2024年度报告.md",
            entity="AIA Group",
            parent_chunk_size=700,
            child_chunk_size=220,
        )
        children = [
            child
            for parent in result["parent_child_chunks"]
            for child in parent["child_contents"]
        ]
        self.assertTrue(any("章节：2024 年度报告 > 经营回顾" in c for c in children))
        self.assertTrue(any("代理人渠道新业务价值增长 15.2%" in c for c in children))
        self.assertTrue(any("检索数值别名：15.2%；15.2" in c for c in children))
        self.assertTrue(
            any(
                "列表路径：代理人渠道新业务价值增长 15.2% > 中国香港市场保持增长" in c
                for c in children
            )
        )

    def test_table_has_row_and_cell_representations(self):
        result = build_parent_child_chunks(MIXED_SAMPLE, entity="AIA Group")
        children = "\n".join(
            child
            for parent in result["parent_child_chunks"]
            for child in parent["child_contents"]
        )
        self.assertIn("各期间数值：2022=1,950；2023=2,180；2024=2,460", children)
        self.assertIn("标准化数值：2460", children)

    def test_long_table_repeats_header_in_each_parent(self):
        rows = "\n".join(f"| 指标{i} | {i:,} | {i + 1:,} |" for i in range(1000, 1030))
        sample = f"""# 长表格
| 指标 | 2023 | 2024 |
| --- | ---: | ---: |
{rows}
"""
        result = build_parent_child_chunks(sample, parent_chunk_size=500)
        table_parents = [
            p["parent_content"]
            for p in result["parent_child_chunks"]
            if "| 指标 | 2023 | 2024 |" in p["parent_content"]
        ]
        self.assertGreater(len(table_parents), 1)
        self.assertTrue(all("表格分片：" in parent for parent in table_parents))

    def test_financial_number_formats_and_footnotes(self):
        sample = """| 指标 | 2022 | 2023 | 2024 |
| --- | ---: | ---: | ---: |
| 新业务价值 | **2,460** | HKD 2,500[1] | 1.2bn |
| 利润率 | **12.8%** | (5.0%) | - |
"""
        result = build_parent_child_chunks(sample, unit="百万美元")
        children = "\n".join(
            child
            for parent in result["parent_child_chunks"]
            for child in parent["child_contents"]
        )
        self.assertIn("标准化数值：2460", children)
        self.assertIn("标准化数值：2500", children)
        self.assertIn("币种：HKD", children)
        self.assertIn("标准化数值：1.2", children)
        self.assertNotIn("1.2bn百万美元", children)
        self.assertIn("单位：%", children)
        self.assertNotIn("12.8%百万美元", children)

    def test_table_inherits_multiple_context_lines(self):
        sample = """# 附注

**分部利润表**
币种：港元
单位：百万元
口径：按固定汇率计算
数据来源：经审计年度报告

| 指标 | 2024 |
| --- | ---: |
| 营运利润 | 2,460 |
"""
        result = build_parent_child_chunks(sample)
        children = "\n".join(
            child
            for parent in result["parent_child_chunks"]
            for child in parent["child_contents"]
        )
        self.assertIn("表名：分部利润表", children)
        self.assertIn("表格币种：港元", children)
        self.assertIn("表格单位：百万元", children)
        self.assertIn("表格上下文：口径：按固定汇率计算", children)
        self.assertIn("表格上下文：数据来源：经审计年度报告", children)
        self.assertIn("币种：HKD", children)

    def test_long_nested_list_repeats_path_in_every_child(self):
        long_text = "。".join(["该市场保持增长"] * 80)
        sample = f"""# 驱动因素
- 渠道增长
  - 香港市场：{long_text}
"""
        result = build_parent_child_chunks(sample, child_chunk_size=200)
        matching = [
            child
            for parent in result["parent_child_chunks"]
            for child in parent["child_contents"]
            if "香港市场" in child
        ]
        self.assertGreater(len(matching), 1)
        self.assertTrue(
            all("列表路径：渠道增长 > 香港市场" in child for child in matching)
        )

    def test_long_code_fence_is_split_and_preserved(self):
        body = "\n".join(f"field_{index}: {index}" for index in range(100))
        sample = f"""# 数据字典

```yaml
{body}
```
"""
        result = build_parent_child_chunks(sample, child_chunk_size=200)
        code_children = [
            child
            for parent in result["parent_child_chunks"]
            for child in parent["child_contents"]
            if "```yaml" in child
        ]
        self.assertGreater(len(code_children), 1)
        self.assertTrue(
            all("```yaml" in child and "\n```" in child for child in code_children)
        )


if __name__ == "__main__":
    unittest.main()
