# Privacy Policy

This plugin processes provided text locally inside the Dify plugin runtime. It does not send document content to external services, does not store content, and does not require credentials.

